﻿namespace List_Copy
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> originalList = new List<int> { 1, 2, 3, 4, 5 };
            List<int> newList = originalList.ToList();
            newList.Add(6);
            newList.Add(7);
            newList.Remove(3);
            Console.WriteLine("Original List:");
            DisplayList(originalList);
            Console.WriteLine("New List:");
            DisplayList(newList);
            Console.ReadLine();
        }

        static void DisplayList(List<int> list)
        {
            foreach (int item in list)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();
        }
    }
}