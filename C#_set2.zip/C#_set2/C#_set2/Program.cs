﻿namespace Shape_Interface
{
    interface IShape
    {
        int Sides { get; }
        double Area { get; }
    }

    class Rectangle : IShape
    {
        public int Sides { get; } = 4;
        public double Width { get; set; }
        public double Height { get; set; }

        public double Area
        {
            get { return Width * Height; }
        }
    }
    class Square : IShape
    {
        public int Sides { get; } = 4;
        public double SideLength { get; set; }

        public double Area
        {
            get { return SideLength * SideLength; }
        }
    }

    class Circle : IShape
    {
        public int Sides { get; } = 0;
        public double Radius { get; set; }

        public double Area
        {
            get { return Math.PI * Radius * Radius; }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Rectangle rectangle = new Rectangle();
            rectangle.Width = 5;
            rectangle.Height = 3;
            Console.WriteLine($"Rectangle: Sides={rectangle.Sides}, Area={rectangle.Area}");

            Square square = new Square();
            square.SideLength = 4;
            Console.WriteLine($"Square: Sides={square.Sides}, Area={square.Area}");

            Circle circle = new Circle();
            circle.Radius = 2.5;
            Console.WriteLine($"Circle: Sides={circle.Sides}, Area={circle.Area}");

            Console.ReadLine();
        }
    }
}