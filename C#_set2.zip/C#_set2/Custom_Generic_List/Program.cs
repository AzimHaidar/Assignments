﻿namespace Custom_Generic_List
{
    class Container<T>
    {
        private List<T> values;

        public Container()
        {
            values = new List<T>();
        }

        public void Add(T item)
        {
            values.Add(item);
        }

        public int Count()
        {
            return values.Count;
        }

        public bool Contains(T item)
        {
            return values.Contains(item);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Container<int> intContainer = new Container<int>();
            intContainer.Add(1);
            intContainer.Add(2);
            intContainer.Add(3);
            Console.WriteLine("Count of Integers: " + intContainer.Count());
            Console.WriteLine("Does it contain 2? " + intContainer.Contains(2));
            Console.WriteLine("Does it contain 4? " + intContainer.Contains(4));

            Container<string> stringContainer = new Container<string>();
            stringContainer.Add("apple");
            stringContainer.Add("banana");
            Console.WriteLine("Count of Strings: " + stringContainer.Count());
            Console.WriteLine("Does it contain 'banana'? " + stringContainer.Contains("banana"));
            Console.WriteLine("Does it contain 'orange'? " + stringContainer.Contains("orange"));

            Container<DateTime> dateContainer = new Container<DateTime>();
            dateContainer.Add(DateTime.Now);
            dateContainer.Add(DateTime.UtcNow);
            Console.WriteLine("Count of Dates: " + dateContainer.Count());
            Console.WriteLine("Does it contain current date? " + dateContainer.Contains(DateTime.Now));
            Console.WriteLine("Does it contain a future date? " + dateContainer.Contains(DateTime.Now.AddDays(1)));

            Console.ReadLine();
        }
    }
}