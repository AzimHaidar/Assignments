﻿namespace Reverse
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a number: "); int n = int.Parse(Console.ReadLine()); CheckReverse(n);
        }
        static void CheckReverse(int n)
        {
            int revNumb = 0; while (n > 0)
            {
                int lastDigit = n % 10;
                revNumb = (revNumb * 10) + lastDigit; n /= 10;
            }
            Console.WriteLine("The reversed number is " + revNumb);
        }
    }
}