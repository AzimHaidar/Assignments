﻿namespace ASCII
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string:"); string str = Console.ReadLine(); FindAscii(str);
        }

        static void FindAscii(string str)
        {
            Console.Write("The ASCII values of the string are: "); 
            for (int i = 0; i < str.Length; i++)
            {
                Console.Write((int)str[i] + " ");
            }
        }
    }
}