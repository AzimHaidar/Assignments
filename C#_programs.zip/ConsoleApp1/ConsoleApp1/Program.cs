﻿using System;
using System.Collections;

namespace Fibonacci
{
    
     class Program
    {

        public static void Main(string[] args)
        {
            Console.Write("Enter the term up to which you wish to print the series: ");
            long n = long.Parse(s: Console.ReadLine()); 
            FiboPrint(n);

        }
        static void FiboPrint(long n)
        {
            long fib, a = 0, b = 1; 
            Console.WriteLine(a + "\n" + b); 
            for (int i = 1; i <= n; i++)
            {
                fib = a + b; 
                if (fib <= n)
                {

                    Console.WriteLine(fib);
                }
                a = b;
                b = fib;
            }
        }
    }
}