﻿namespace NumToWords
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a number: "); 
            int n = int.Parse(Console.ReadLine());
            Console.Write(n + " in words is: "); 
            ConvertNum(n);
        }
        static void ConvertNum(int n)
        {
            string[] words = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };

            foreach (char c in n.ToString())
            {
                int digit = int.Parse(c.ToString()); 
                Console.Write(words[digit] + " ");
            }
        }
    
    }
}