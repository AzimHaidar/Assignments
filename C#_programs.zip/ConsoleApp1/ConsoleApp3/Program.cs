﻿namespace Armstrong
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a number: ");
            int n = int.Parse(s: Console.ReadLine()); CheckArmstrong(n);
        }
        static void CheckArmstrong(int n)
        {
            int count = 0, temp, sum = 0, digit = 0; temp = n;
            while (temp > 0)
            {
                count++;

                temp /= 10;
            }
            temp = n;
            while (temp > 0)
            {
                digit = temp % 10;
                sum += (int)Math.Pow(digit, count); temp /= 10;
            }
            if (sum == n)
            {
                Console.WriteLine("The number is an Armstrong number");
            }
            else
            {
                Console.WriteLine("The number is not an Armstrong number");
            }
        }


    }
}