﻿namespace PrimeNumber
{
    internal class Program
    {
        static void Main(string[] args)
        {
            System.Console.Write("Enter a number: "); int n = int.Parse(Console.ReadLine()); CheckPrime(n);
        }
        static void CheckPrime(int n)
        {
            if (n < 2)
            {
                Console.WriteLine("It is not a prime number");
            }
            else if (n == 2)
            {
                Console.WriteLine("It is a prime number");
            }
            else if (n > 2)
            {
                int limit = (int)Math.Sqrt(n);

                for (int i = 2; i <= limit; i++)
                {
                    if (n % i == 0)
                    {
                        Console.WriteLine("It is not a prime number ");
                    }
                    else { Console.WriteLine("It is a prime number"); }
                }


            }
        }

    }
}