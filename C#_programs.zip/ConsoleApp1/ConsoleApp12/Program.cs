﻿namespace FrequentOccurence
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string:"); string str = Console.ReadLine(); FrequentChar(str);
        }

        static void FrequentChar(string str)
        {
            Dictionary<char, int> charCount = new Dictionary<char, int>(); 
            foreach (char c in str)
            {
                if (charCount.ContainsKey(c))
                {
                    charCount[c]++;
                }
                else
                {
                    charCount[c] = 1;
                }
            }
            char maxChar = '\0';
            int maxCount = 0;
            foreach (KeyValuePair<char, int> pair in charCount)
            {
                if (pair.Value > maxCount)
                {
                    maxChar = pair.Key; maxCount = pair.Value;
                }
            }
            if (maxCount > 1)
            {
                Console.WriteLine("The most frequently occurring character in the string is: " + maxChar);
            }
            else
            {

                Console.WriteLine("no");
            }

        }
    }
    }