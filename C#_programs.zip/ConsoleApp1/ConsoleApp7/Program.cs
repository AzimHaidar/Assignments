﻿namespace Factorial
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.Write("Enter the value of n: "); int n = int.Parse(Console.ReadLine()); ListFactorial(n);
        }
        public static void ListFactorial(int n)
        {
            Console.WriteLine("Factorial Numbers up to " + n + " terms: "); for (int i = 1; i <= n; i++)
            {
                int factorial = 1;
                for (int j = i; j >= 1; j--)
                {

                    factorial *= j;
                }
                Console.Write(factorial + " ");
            }
        }
    }
}