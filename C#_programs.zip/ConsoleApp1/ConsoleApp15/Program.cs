﻿namespace SumOfDivisibleBy3and4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            for (int i = 1; i <= 20; i++)
            {
                if (i % 3 == 0 && i % 4 == 0)
                {
                    sum += i;
                }
            }
            Console.WriteLine("The sum of all the numbers between 1 and 20 which are divisible by 3 and 4 is: "
            + sum);
        }
    }
}