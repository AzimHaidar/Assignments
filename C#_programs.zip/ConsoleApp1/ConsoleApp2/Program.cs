﻿namespace Anagram
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the first string: "); string str1 = Console.ReadLine(); Console.Write("Enter the Second string: "); string str2 = Console.ReadLine(); CheckAnagram(str1, str2);
        }
        static void CheckAnagram(string str1, string str2)
        {
            if (str1.Length != str2.Length)
            {
                Console.WriteLine("Strings aren't anagrams");
            }
            else
            {
                char[] strArr1 = str1.ToCharArray(); char[] strArr2 = str2.ToCharArray();

                Array.Sort(strArr1); Array.Sort(strArr2);
                bool isEqual = true;
                for (int i = 0; i < strArr1.Length; i++)
                {
                    if (strArr1[i] != strArr2[i])
                    {
                        isEqual = false; break;
                    }
                }
                if (isEqual)
                {
                    Console.WriteLine("Strings are Anagram");
                }
                else
                {
                    Console.WriteLine("Strings aren't Anagram");
                }
            }
            Console.ReadLine();
        }

    }
}