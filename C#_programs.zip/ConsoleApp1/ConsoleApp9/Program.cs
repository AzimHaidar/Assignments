﻿namespace AllElementsDivisible
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of elements in the array:"); int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];
            Console.WriteLine("Enter the elements of the array:"); for (int i = 0; i < n; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }
            int gcd = arr[0];
            for (int i = 1; i < n; i++)

            {
                gcd = GCD(gcd, arr[i]);
            }
            bool flag = true;
            for (int i = 0; i < n; i++)
            {
                if (arr[i] % gcd != 0)
                {
                    flag = false; break;
                }
            }
            if (flag)
            {
                Console.WriteLine(gcd);
            }
            else
            {
                Console.WriteLine("-1");
            }
        }
        static int GCD(int a, int b)
        {
            if (b == 0)
            {
                return a;
            }
            else
            {
                return GCD(b, a % b);
            }
        }

    }
}