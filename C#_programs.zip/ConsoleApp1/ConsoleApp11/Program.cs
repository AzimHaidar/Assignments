﻿namespace SmallestAndGreatest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of elements in the array:"); 
            int n = int.Parse(Console.ReadLine());
            FindNum(n);
        }

        static void FindNum(int n)
        {
            int[] arr = new int[n];
            Console.WriteLine("Enter the elements of the array:");
            for (int i = 0; i < n; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }
            int min = arr[0];
            int max = arr[0];
            for (int i = 1; i < n; i++)
            {
                if (arr[i] < min)
                {
                    min = arr[i];
                }
                if (arr[i] > max)
                {
                    max = arr[i];
                }
            }

            Console.WriteLine("The smallest number in the array is: " + min); Console.WriteLine("The largest number in the array is: " + max);
        }
    }
}