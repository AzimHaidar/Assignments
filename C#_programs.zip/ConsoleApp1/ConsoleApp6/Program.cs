﻿namespace BubbleSort
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of elements: "); int n = Convert.ToInt32(Console.ReadLine()); SortArray(n);
        }

        static void SortArray(int n)
        {
            int[] arr = new int[n];
            Console.WriteLine("Enter the elements of the array: "); for (int i = 0; i < n; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        int temp = arr[j]; arr[j] = arr[j + 1]; arr[j + 1] = temp;
                    }
                }
            }

            Console.WriteLine("Sorted array is :"); for (int i = 0; i < n; i++)
            {
                Console.Write(arr[i] + " ");
            }
        }
    }
}