﻿namespace Circle {
    class Circle
    {

        private double radius;

        public double Radius
        {
            get { return radius; }
            set
            {
                if (value < 0)
                    throw new ArgumentException("Radius cannot be negative.");

                radius = value;
            }
        }

        public double Circumference
        {
            get { return 2 * 3.14159 * radius; }
        }

        public double Area
        {
            get { return 3.14159 * radius * radius; }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the radius of the circle: ");
            double radius = Convert.ToDouble(Console.ReadLine());

            Circle circle = new Circle();
            circle.Radius = radius;

            Console.WriteLine("Circumference: " + circle.Circumference);
            Console.WriteLine("Area: " + circle.Area);

            Console.ReadLine();
        }
    }
}