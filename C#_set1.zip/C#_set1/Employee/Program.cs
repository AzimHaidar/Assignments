﻿namespace Employee
{
    class Employee
    {
        public string Name { get; set; }
        public DateTime JoiningDate { get; set; }
        public decimal Salary { get; set; }
        public string Designation { get; set; }

        public bool HasCompleted6Months()
        {
            DateTime sixMonthsAgo = DateTime.Today.AddMonths(-6);
            return JoiningDate <= sixMonthsAgo;
        }

        public override string ToString()
        {
            string completed6Months = HasCompleted6Months() ? "Yes" : "No";
            return $"Name: {Name}\nJoining Date: {JoiningDate.ToShortDateString()}\nSalary: {Salary}\nDesignation: {Designation}\nCompleted 6 Months: {completed6Months}";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee();

            Console.Write("Enter Name: ");
            employee.Name = Console.ReadLine();

            Console.Write("Enter Joining Date (MM/dd/yyyy): ");
            employee.JoiningDate = DateTime.ParseExact(Console.ReadLine(), "MM/dd/yyyy", null);

            Console.Write("Enter Salary: ");
            employee.Salary = decimal.Parse(Console.ReadLine());

            Console.Write("Enter Designation: ");
            employee.Designation = Console.ReadLine();

            Console.WriteLine("\nEmployee Details:");
            Console.WriteLine(employee);

            Console.ReadLine();
        }
    }
}