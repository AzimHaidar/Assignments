﻿namespace Size_Print
{
  
    internal class Program
    {
        static void Main(string[] args)
        {
           
                Console.WriteLine("Size of bool: " + sizeof(bool) + " bytes");
                Console.WriteLine("Size of char: " + sizeof(char) + " bytes");
                Console.WriteLine("Size of decimal: " + sizeof(decimal) + " bytes");
                Console.WriteLine("Size of uint: " + sizeof(uint) + " bytes");
                Console.WriteLine("Size of ushort: " + sizeof(ushort) + " bytes");

                Console.ReadLine();
            
        }
    }
}