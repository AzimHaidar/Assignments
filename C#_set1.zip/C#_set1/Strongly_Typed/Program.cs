﻿namespace Strongly_Typed
{

    class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"C:\Users\Admin\Desktop\Azim\C#_set1\Strongly_Typed\data.txt";

            string data = ReadDataFromFile(filePath);
            FileData fileData = ParseFileData(data);
            DisplayFileData(fileData);

            Console.ReadLine();
        }
        static string ReadDataFromFile(string filePath)
        {
            try
            {
                return File.ReadAllText(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error reading the file: " + ex.Message);
                return string.Empty;
            }
        }

        static FileData ParseFileData(string data)
        {
            FileData fileData = new FileData();
            List<string> tickers = new List<string>();
            List<string> fields = new List<string>();
            List<string> fileDataList = new List<string>();

            bool isTickerSection = false;
            bool isFieldSection = false;
            bool isDataSection = false;

            string[] lines = data.Split('\n', StringSplitOptions.RemoveEmptyEntries);

            foreach (string line in lines)
            {
                string trimmedLine = line.Trim();

                switch (trimmedLine)
                {
                    case "START-OF-FILE":
                        break;
                    case "START-OF-TICKERS":
                        isTickerSection = true;
                        break;
                    case "END-OF-TICKERS":
                        isTickerSection = false;
                        break;
                    case "START-OF-FIELDS":
                        isFieldSection = true;
                        break;
                    case "END-OF-FIELDS":
                        isFieldSection = false;
                        break;
                    case "START-OF-DATA":
                        isDataSection = true;
                        break;
                    case "END-OF-DATA":
                        isDataSection = false;
                        break;
                    default:
                        if (isTickerSection)
                            tickers.Add(trimmedLine);
                        else if (isFieldSection)
                            fields.Add(trimmedLine);
                        else if (isDataSection)
                            fileDataList.Add(trimmedLine);
                        else
                            ParseKeyValuePair(trimmedLine, fileData);
                        break;
                }
            }

            fileData.TICKERS = tickers.ToArray();
            fileData.FIELDS = fields.ToArray();
            fileData.DATA = fileDataList.ToArray();

            return fileData;
        }

        static void ParseKeyValuePair(string line, FileData fileData)
        {
            string[] parts = line.Split('=');
            if (parts.Length == 2)
            {
                string key = parts[0].Trim();
                string value = parts[1].Trim();

                switch (key)
                {
                    case "FIRMNAME":
                        fileData.FIRMNAME = value;
                        break;
                    case "FILETYPE":
                        fileData.FILETYPE = value;
                        break;
                }
            }
        }

        static void DisplayFileData(FileData fileData)
        {
            Console.WriteLine("FIRMNAME: " + fileData.FIRMNAME);
            Console.WriteLine("FILETYPE: " + fileData.FILETYPE);

            Console.WriteLine("TICKERS:");
            foreach (var ticker in fileData.TICKERS)
            {
                Console.WriteLine(" - " + ticker);
            }

            Console.WriteLine("FIELDS:");
            foreach (var field in fileData.FIELDS)
            {
                Console.WriteLine(" - " + field);
            }

            Console.WriteLine("DATA:");
            foreach (var entry in fileData.DATA)
            {
                Console.WriteLine(" - " + entry);
            }
        }
    }




    class FileData
    {
        public string FIRMNAME { get; set; }
        public string FILETYPE { get; set; }
        public string[] TICKERS { get; set; }
        public string[] FIELDS { get; set; }
        public string[] DATA { get; set; }
    }
}