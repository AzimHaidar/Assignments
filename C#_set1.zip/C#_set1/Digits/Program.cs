﻿namespace Digits
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a number: ");
            int number = int.Parse(Console.ReadLine());

            string magnitude = GetMagnitude(number);

            Console.WriteLine($"Magnitude: {magnitude}");

            Console.ReadLine();
        }

        static string GetMagnitude(int number)
        {

            return number switch
            {
                >= 0 and < 10 => "Units",
                >= 10 and < 100 => "Tens",
                >= 100 and < 1000 => "Hundreds",
                >= 1000 and < 1000000 => "Thousands",
                _ => "Millions"
            };


        }
    }
}