﻿namespace Record_List
{

    

    class Program
    {
        record Employee(string Name, string Department, string Designation, decimal Salary);
        static void Main(string[] args)
        {
            List<Employee> employees = new List<Employee>
        {
            new Employee("John Doe", "HR", "Manager", 6000),
            new Employee("Jane Smith", "Finance", "Accountant", 5500),
            new Employee("Mike Johnson", "IT", "Developer", 4800),
            new Employee("Emily Davis", "Marketing", "Marketing Specialist", 7000),
            new Employee("David Lee", "Operations", "Supervisor", 5200)
        };

            Console.WriteLine("Employees with Salary > 5000:");
            foreach (var employee in employees)
            {
                if (employee.Salary > 5000)
                    Console.WriteLine(employee);
            }

            Console.WriteLine();

            Console.WriteLine("All Employees:");
            foreach (var employee in employees)
            {
                Console.WriteLine(employee);
            }

            Console.ReadLine();
        }
    }
}