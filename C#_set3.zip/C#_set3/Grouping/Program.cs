﻿namespace Grouping
{
    record Employee(string Name, string Department, decimal Salary);

    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> employees = new List<Employee>
        {
            new Employee("John Doe", "HR", 6000),
            new Employee("Jane Smith", "Finance", 5500),
            new Employee("Mike Johnson", "IT", 4800),
            new Employee("Emily Davis", "Marketing", 7000),
            new Employee("David Lee", "Operations", 5200),
            new Employee("Alex Brown", "Finance", 12000),
            new Employee("Sarah Green", "HR", 10000),
            new Employee("Robert Wilson", "IT", 18000),
            new Employee("Olivia Parker", "Marketing", 25000),
            new Employee("Daniel Taylor", "Operations", 22000),
            new Employee("Emma Clark", "Finance", 50000),
            new Employee("Michael Davis", "HR", 35000),
            new Employee("Sophia Miller", "IT", 28000),
            new Employee("Liam Johnson", "Marketing", 55000),
            new Employee("Oliver White", "Operations", 42000)
        };

            // Group employees by department
            Dictionary<string, List<Employee>> employeesByDepartment = employees
                .GroupBy(e => e.Department)
                .ToDictionary(g => g.Key, g => g.ToList());

            Console.WriteLine("Employees grouped by Department:");
            foreach (var department in employeesByDepartment)
            {
                Console.WriteLine(department.Key);
                foreach (var employee in department.Value)
                {
                    Console.WriteLine(" - " + employee.Name);
                }
                Console.WriteLine();
            }

            Console.WriteLine("----------------------------------------");
            Console.WriteLine();

            // Group employees by salary brackets
            Dictionary<string, List<Employee>> employeesBySalaryBracket = employees
                .GroupBy(e => GetSalaryBracket(e.Salary))
                .ToDictionary(g => g.Key, g => g.ToList());

            Console.WriteLine("Employees grouped by Salary Brackets:");
            foreach (var salaryBracket in employeesBySalaryBracket)
            {
                Console.WriteLine(salaryBracket.Key);
                foreach (var employee in salaryBracket.Value)
                {
                    Console.WriteLine(" - " + employee.Name);
                }
                Console.WriteLine();
            }

            Console.ReadLine();
        }

        static string GetSalaryBracket(decimal salary)
        {
            if (salary > 50000)
                return ">50000";
            else if (salary > 20000)
                return ">20000";
            else if (salary > 10000)
                return ">10000";
            else if (salary > 5000)
                return ">5000";
            else
                return "<=5000";
        }
    }
}