﻿namespace Reverse
{

    class Program
    {
        static void Main(string[] args)
        {
            // Reverse a string
            string originalString = "Hello, World!";
            string reversedString = Reverse(originalString);
            Console.WriteLine("Original String: " + originalString);
            Console.WriteLine("Reversed String: " + reversedString);

            Console.WriteLine();

            // Reverse a number
            int originalNumber = 12345;
            int reversedNumber = Reverse(originalNumber);
            Console.WriteLine("Original Number: " + originalNumber);
            Console.WriteLine("Reversed Number: " + reversedNumber);

            Console.ReadLine();
        }

        static T Reverse<T>(T value)
        {
            char[] charArray = value.ToString().ToCharArray();
            Array.Reverse(charArray);
            string reversedString = new string(charArray);
            return (T)Convert.ChangeType(reversedString, typeof(T));
        }
    }
}